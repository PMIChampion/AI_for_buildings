'use client';

import Groups from '../../components/Groups';


export default function View() {

  return (
      <Groups />
  );
}