'use client';

import ViewImages from '../../components/ViewImages';


export default function View() {

  return (
      <ViewImages />
  );
}