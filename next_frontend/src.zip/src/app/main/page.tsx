'use client';

import HomeContent from '../../components/HomeContent';


export default function Home() {

  return (
      <HomeContent />
  );
}